import { patch } from "@web/core/utils/patch";
import { onMounted, onPatched } from "@odoo/owl";
import { AccountLabelTextField } from "@account/components/account_label_text/account_label_text";

/**
 * Fahires: clicking an empty Description cell on a document line opens the
 * product list straight away (before typing). Typing then filters it as usual.
 */
patch(AccountLabelTextField.prototype, {
    setup() {
        super.setup(...arguments);
        const attach = () => {
            const textarea = this.textareaRef && this.textareaRef();
            if (!textarea || textarea._fahiresShowAll) {
                return;
            }
            textarea._fahiresShowAll = true;
            textarea.addEventListener("click", () => this._fahiresShowAllProducts());
        };
        onMounted(attach);
        onPatched(attach);
    },
    _fahiresShowAllProducts() {
        const textarea = this.textareaRef && this.textareaRef();
        if (!textarea || this.props.readonly || !this.canEditProduct || this.product) {
            return;
        }
        if (this.getFirstLine(textarea.value) || this.isDropdownVisible) {
            return;
        }
        const input = this.m2xInput;
        if (input) {
            input.dispatchEvent(new MouseEvent("click", { bubbles: true }));
        }
    },
});
