import { patch } from "@web/core/utils/patch";
import { SaleOrderLineProductField } from "@sale/js/sale_product_field/sale_product_field";

/**
 * Quotation lines: when a product is chosen on the LAST product line,
 * automatically open a new empty line (same as clicking "Add a product").
 */
patch(SaleOrderLineProductField.prototype, {
    async _onProductUpdate() {
        await super._onProductUpdate(...arguments);
        this._fahiresAutoAddLine();
    },

    _fahiresAutoAddLine() {
        const record = this.props.record;
        const root = record.model.root;
        if (root.resModel !== "sale.order" || !root.data.order_line) {
            return;
        }
        const productLines = root.data.order_line.records.filter((r) => !r.data.display_type);
        if (productLines[productLines.length - 1] !== record) {
            return; // only when the last line was filled
        }
        const fieldEl = document.querySelector(
            '.o_form_view .o_field_widget[name="order_line"] .o_field_x2many_list_row_add a'
        );
        if (fieldEl) {
            setTimeout(() => fieldEl.isConnected && fieldEl.click(), 250);
        }
    },
});
