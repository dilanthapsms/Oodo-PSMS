import { patch } from "@web/core/utils/patch";
import { useOnChange } from "@odoo/owl";
import { SaleOrderLineListRenderer } from "@sale/js/sale_order_line_field/sale_order_line_field";

/**
 * Fahires: when the last product line of a quotation gets a product,
 * automatically open a new empty line so the user can keep typing.
 */
patch(SaleOrderLineListRenderer.prototype, {
    setup() {
        super.setup(...arguments);
        const productOf = (r) => {
            const d = r.data;
            return (d.product_id && d.product_id.id) || (d.product_template_id && d.product_template_id.id) || false;
        };
        const lastKey = () => {
            const list = this.props.list;
            if (!list || list.resModel !== "sale.order.line") {
                return "";
            }
            const lines = list.records.filter((r) => !r.data.display_type);
            const last = lines[lines.length - 1];
            return last ? `${last.id}:${productOf(last) || ""}` : "";
        };
        let previous = lastKey();
        useOnChange(
            () => [lastKey()],
            (current) => {
                const [prevId, prevProd] = (previous || "").split(":");
                const [curId, curProd] = (current || "").split(":");
                previous = current;
                if (!curId || curId !== prevId || !curProd || prevProd || this.props.readonly) {
                    return;
                }
                const list = this.props.list;
                const tryAdd = (attempt) => {
                    const lastRec = list.records.at(-1);
                    if (!lastRec || lastRec.id !== curId || this.props.readonly) {
                        return; // a new line exists already, or the form changed
                    }
                    // wait while a dialog (e.g. product configurator) is open
                    const busy = document.body.classList.contains("modal-open");
                    if (!busy) {
                        this.add({ context: undefined });
                    }
                    if (attempt < 30) {
                        setTimeout(() => tryAdd(attempt + 1), 500);
                    }
                };
                setTimeout(() => tryAdd(0), 300);
            },
            { initialRun: false }
        );
    },
});
