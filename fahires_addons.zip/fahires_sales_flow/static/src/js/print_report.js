import { registry } from "@web/core/registry";
import { user } from "@web/core/user";
import { _t } from "@web/core/l10n/translation";
import { getReportUrl } from "@web/webclient/actions/reports/utils";

/**
 * Fahires: PDF reports open the browser's Print dialog instead of downloading.
 * (The dialog still offers "Save as PDF".) Pass context {fahires_download: true}
 * on an action to keep the old download behaviour.
 */
async function fahiresPrintReport(action, options, env) {
    if (action.report_type !== "qweb-pdf" || (action.context && action.context.fahires_download)) {
        return false;
    }
    const context = { ...user.context, ...(action.context || {}) };
    let url = getReportUrl(action, "pdf", context);
    if (!url.includes("context=")) {
        url += (url.includes("?") ? "&" : "?") + "context=" + encodeURIComponent(JSON.stringify(context));
    }
    env.services.ui.block();
    let blob;
    try {
        const response = await fetch(url, { credentials: "same-origin" });
        const type = response.headers.get("Content-Type") || "";
        if (!response.ok || !type.includes("pdf")) {
            return false; // let Odoo handle it (shows the proper error)
        }
        blob = await response.blob();
    } catch {
        return false;
    } finally {
        env.services.ui.unblock();
    }
    const blobUrl = URL.createObjectURL(new Blob([blob], { type: "application/pdf" }));
    document.querySelectorAll("iframe.o_fahires_print_frame").forEach((f) => f.remove());
    const frame = document.createElement("iframe");
    frame.className = "o_fahires_print_frame";
    frame.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden;";
    frame.onload = () => {
        setTimeout(() => {
            try {
                frame.contentWindow.focus();
                frame.contentWindow.print();
            } catch {
                // Browser refused printing from the frame: open the PDF in a new tab instead
                window.open(blobUrl, "_blank");
                env.services.notification.add(_t("Use Ctrl+P to print the document."), { type: "info" });
            }
        }, 300);
    };
    frame.src = blobUrl;
    document.body.appendChild(frame);
    return true;
}

registry.category("ir.actions.report handlers").add("fahires_print_report", fahiresPrintReport);
