from . import controllers
from . import models
from . import wizard


def _post_init_set_stages(env):
    """Place existing quotations / orders in the matching pipeline stage."""
    env["sale.order"].search([])._fahires_sync_stage_from_state(force=True)
