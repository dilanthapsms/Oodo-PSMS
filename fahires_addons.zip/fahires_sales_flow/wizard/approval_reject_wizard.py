from odoo import fields, models


class ApprovalRejectWizard(models.TransientModel):
    _name = "fahires.approval.reject.wizard"
    _description = "Reject Quotation with Remarks"

    order_ids = fields.Many2many("sale.order", string="Quotations")
    remarks = fields.Text(required=True, help="Explain what must be changed. Shown on the deal card.")

    def action_reject(self):
        self.ensure_one()
        self.order_ids._fahires_reject(self.remarks)
        return {"type": "ir.actions.act_window_close"}
