{
    "name": "Fahires Sales Pipeline & Approvals",
    "version": "20.0.1.0.0",
    "category": "Sales/Sales",
    "summary": "Deal pipeline kanban for quotations with internal approvals and customer responses",
    "description": """
* Deal pipeline (kanban) for quotations with totals and counts per stage:
  Draft QT > Pending Approval > Sent to Customer > Customer Responded >
  Pending Delivery > Pending Invoice > Pending Payment > Archive
* Approvals app: approval rules for Quotations, Customer Invoices and Purchase Orders
* Send for Approval / Approve / Reject with remarks (rejected QTs go back to Draft, labelled)
* Approvers can send their own quotations directly to the customer
* Customer accept / reject / remarks from the portal link update the deal immediately
* Time-in-stage on every card
""",
    "author": "Fahires",
    "license": "LGPL-3",
    "depends": ["sale_management", "portal", "mail"],
    "data": [
        "security/ir.access.csv",
        "data/sale_flow_stage_data.xml",
        "wizard/approval_reject_wizard_views.xml",
        "views/sale_flow_stage_views.xml",
        "views/approval_rule_views.xml",
        "views/sale_order_views.xml",
        "views/menus.xml",
    ],
    "assets": {
        "web.assets_backend": [
            "fahires_sales_flow/static/src/kanban_header.xml",
            "fahires_sales_flow/static/src/js/auto_new_line.js",
            "fahires_sales_flow/static/src/js/label_show_all.js",
        ],
    },
    "post_init_hook": "_post_init_set_stages",
    "installable": True,
    "application": False,
}
