from odoo import fields, models

STAGE_CODES = [
    ("draft", "Draft QT"),
    ("approval", "Pending Approval"),
    ("sent", "Sent to Customer"),
    ("responded", "Customer Responded"),
    ("delivery", "Pending Delivery"),
    ("invoice", "Pending Invoice"),
    ("payment", "Pending Payment"),
    ("archive", "Archive"),
]


class SaleFlowStage(models.Model):
    _name = "fahires.sale.flow.stage"
    _description = "Deal Pipeline Stage"
    _order = "sequence, id"

    name = fields.Char(required=True, translate=True)
    code = fields.Selection(STAGE_CODES, required=True, help="Technical step used by the automation.")
    sequence = fields.Integer(default=10)
    fold = fields.Boolean("Folded in Kanban")
    description = fields.Text()

    _code_unique = models.Constraint("UNIQUE(code)", "Each pipeline step can only have one stage.")
