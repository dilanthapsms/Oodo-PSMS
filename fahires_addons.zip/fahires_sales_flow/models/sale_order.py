from markupsafe import Markup

from odoo import _, api, fields, models
from odoo.exceptions import UserError
from odoo.tools import html2plaintext

FLOW_LABELS = [
    ("none", "In progress"),
    ("returned", "Returned by Approver"),
    ("ok_to_send", "Approved - Ready to Send"),
    ("approved", "Customer Approved"),
    ("rejected", "Customer Rejected"),
    ("remarks", "Customer Remarks"),
]


class SaleOrder(models.Model):
    _inherit = "sale.order"

    # ------------------------------------------------------------------ fields
    flow_stage_id = fields.Many2one(
        "fahires.sale.flow.stage",
        string="Pipeline Stage",
        default=lambda s: s._fahires_stage("draft"),
        group_expand="_read_group_flow_stage_ids",
        tracking=True,
        copy=False,
        index=True,
        ondelete="restrict",
    )
    flow_stage_code = fields.Selection(related="flow_stage_id.code", store=True, string="Stage Step")
    flow_stage_date = fields.Datetime(
        "In Stage Since", default=fields.Datetime.now, copy=False, readonly=True
    )
    flow_stage_duration = fields.Char("Time in Stage", compute="_compute_flow_stage_duration")

    approval_rule_id = fields.Many2one("fahires.approval.rule", "Approval Rule", copy=False, readonly=True)
    approval_state = fields.Selection(
        [("none", "Not Requested"), ("pending", "Pending Approval"),
         ("approved", "Approved"), ("rejected", "Rejected")],
        default="none", copy=False, tracking=True, readonly=True,
    )
    approval_user_id = fields.Many2one("res.users", "Approved / Rejected By", copy=False, readonly=True)
    approval_date = fields.Datetime(copy=False, readonly=True)
    approval_user_name = fields.Char(related="approval_user_id.name", string="Approver Name")
    approval_remarks = fields.Text("Approver Remarks", copy=False)
    needs_approval = fields.Boolean(compute="_compute_approval_flags")
    is_approver = fields.Boolean(compute="_compute_approval_flags")
    approval_applicable = fields.Boolean(compute="_compute_approval_flags")

    response_label = fields.Selection(
        [("approved", "Approved"), ("rejected", "Rejected"), ("remarks", "Remarks")],
        string="Customer Response", copy=False, tracking=True, readonly=True,
    )
    response_remarks = fields.Text("Customer Remarks", copy=False, readonly=True)
    response_date = fields.Datetime("Responded On", copy=False, readonly=True)
    flow_label = fields.Selection(FLOW_LABELS, compute="_compute_flow_label", store=True, string="Label")

    # ------------------------------------------------------------------ helpers
    def _fahires_stage(self, code):
        return self.env["fahires.sale.flow.stage"].search([("code", "=", code)], limit=1)

    @api.model
    def _read_group_flow_stage_ids(self, stages, domain):
        return self.env["fahires.sale.flow.stage"].search([])

    def _fahires_set_stage(self, code, **extra):
        stage = self._fahires_stage(code)
        if not stage:
            return
        ctx_self = self.with_context(fahires_flow_internal=True)
        if extra:
            ctx_self.write(dict(extra))
        to_move = ctx_self.filtered(lambda o: o.flow_stage_id != stage)
        if to_move:
            to_move.write({"flow_stage_id": stage.id, "flow_stage_date": fields.Datetime.now()})

    def _fahires_sync_stage_from_state(self, force=False):
        """Map the standard order state to a pipeline stage (install / safety net)."""
        for order in self:
            if order.flow_stage_id and not force:
                continue
            if order.state == "cancel":
                code = "archive"
            elif order.state == "sale":
                if order.invoice_status == "invoiced":
                    code = "payment" if any(
                        m.payment_state not in ("paid", "in_payment", "reversed")
                        for m in order.invoice_ids.filtered(lambda m: m.state == "posted")
                    ) else "archive"
                else:
                    code = "responded"
            elif order.state == "sent":
                code = "sent"
            else:
                code = "draft"
            order._fahires_set_stage(code)

    @api.depends("flow_stage_date")
    def _compute_flow_stage_duration(self):
        now = fields.Datetime.now()
        for order in self:
            if not order.flow_stage_date:
                order.flow_stage_duration = False
                continue
            delta = now - order.flow_stage_date
            days = delta.days
            if days >= 1:
                order.flow_stage_duration = _("%s day", days) if days == 1 else _("%s days", days)
            else:
                hours, rem = divmod(delta.seconds, 3600)
                order.flow_stage_duration = _("%(h)sh %(m)sm", h=hours, m=rem // 60)

    @api.depends("approval_state", "response_label")
    def _compute_flow_label(self):
        for order in self:
            if order.response_label:
                order.flow_label = order.response_label
            elif order.approval_state == "rejected":
                order.flow_label = "returned"
            elif order.approval_state == "approved":
                order.flow_label = "ok_to_send"
            else:
                order.flow_label = "none"

    def _fahires_get_rule(self):
        self.ensure_one()
        return self.env["fahires.approval.rule"]._get_rule("sale", self.amount_total, self.company_id)

    @api.depends("amount_total", "approval_state", "state", "company_id")
    @api.depends_context("uid")
    def _compute_approval_flags(self):
        for order in self:
            rule = order.approval_rule_id or order._fahires_get_rule()
            order.is_approver = bool(rule) and self.env.user in rule.approver_ids
            order.approval_applicable = bool(rule)
            order.needs_approval = (
                order.state == "draft"
                and bool(rule)
                and order.approval_state != "approved"
                and not order.is_approver
            )

    # ------------------------------------------------------------------ approval actions
    def action_send_for_approval(self):
        for order in self:
            if order.state != "draft":
                raise UserError(_("Only draft quotations can be sent for approval."))
            if not order.order_line:
                raise UserError(_("Add at least one product before sending %s for approval.", order.name))
            rule = order._fahires_get_rule()
            if not rule:
                raise UserError(_("No approval rule applies to %s. You can send it to the customer directly.",
                                  order.name))
            order.write({
                "approval_rule_id": rule.id,
                "approval_state": "pending",
                "approval_remarks": False,
                "approval_user_id": False,
                "approval_date": False,
            })
            order._fahires_set_stage("approval")
            for user in rule.approver_ids:
                order.activity_schedule(
                    "mail.mail_activity_data_todo",
                    summary=_("Approve quotation %s", order.name),
                    note=_("%(user)s requests approval for %(qt)s (%(amount)s).",
                           user=self.env.user.name, qt=order.name,
                           amount=order.currency_id.format(order.amount_total)),
                    user_id=user.id,
                )
            order.message_post(body=_("Sent for approval to %s.", ", ".join(rule.approver_ids.mapped("name"))))
        return True

    def _fahires_check_approver(self):
        for order in self:
            rule = order.approval_rule_id or order._fahires_get_rule()
            if self.env.user not in rule.approver_ids and not self.env.is_superuser():
                raise UserError(_("You are not an authorized approver for %s.", order.name))

    def _fahires_close_approval_activities(self, feedback):
        activities = self.activity_ids.filtered(
            lambda a: a.summary and a.summary.startswith(_("Approve quotation"))
        )
        for activity in activities:
            if activity.user_id == self.env.user:
                activity.action_feedback(feedback=feedback)
            else:
                activity.unlink()

    def action_approve(self):
        self._fahires_check_approver()
        for order in self:
            if order.approval_state != "pending":
                raise UserError(_("%s is not waiting for approval.", order.name))
            order.write({
                "approval_state": "approved",
                "approval_user_id": self.env.user.id,
                "approval_date": fields.Datetime.now(),
            })
            order._fahires_close_approval_activities(_("Approved"))
            order.message_post(body=_("Quotation approved by %s.", self.env.user.name))
            order._fahires_send_after_approval()
        return True

    def _fahires_send_after_approval(self):
        """Approved quotation goes straight to 'Sent to Customer':
        e-mail the quotation to the customer (if it has an e-mail) and move the stage."""
        for order in self:
            sent_by_mail = False
            if order.partner_id.email and order.state in ("draft", "sent"):
                template = order._find_mail_template()
                if template:
                    order.with_context(fahires_flow_internal=True)._send_order_notification_mail(
                        template, allow_deferred_sending=False)
                    sent_by_mail = True
            if order.state == "draft":
                order.with_context(fahires_flow_internal=True).write({"state": "sent"})
            order._fahires_set_stage("sent", response_label=False)
            if sent_by_mail:
                order.message_post(body=_("Approved quotation e-mailed to %s.", order.partner_id.email))
            elif order.user_id:
                order.activity_schedule(
                    "mail.mail_activity_data_todo",
                    summary=_("Customer has no e-mail: send approved quotation %s manually", order.name),
                    user_id=order.user_id.id,
                )

    def action_open_reject_wizard(self):
        self._fahires_check_approver()
        return {
            "type": "ir.actions.act_window",
            "name": _("Reject Quotation"),
            "res_model": "fahires.approval.reject.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {"default_order_ids": self.ids},
        }

    def _fahires_reject(self, remarks):
        self._fahires_check_approver()
        for order in self:
            order.write({
                "approval_state": "rejected",
                "approval_user_id": self.env.user.id,
                "approval_date": fields.Datetime.now(),
                "approval_remarks": remarks,
            })
            order._fahires_set_stage("draft")
            order._fahires_close_approval_activities(_("Rejected: %s", remarks))
            order.message_post(body=Markup("<b>%s</b><br/>%s") % (
                _("Rejected by %s", self.env.user.name), remarks))
            if order.user_id and order.user_id != self.env.user:
                order.activity_schedule(
                    "mail.mail_activity_data_todo",
                    summary=_("Quotation %s returned by approver", order.name),
                    note=remarks,
                    user_id=order.user_id.id,
                )

    # ------------------------------------------------------------------ customer side
    def action_quotation_send(self):
        for order in self.filtered(lambda o: not o.env.su):
            if order.needs_approval:
                raise UserError(_(
                    "%s needs approval before it can be sent to the customer. "
                    "Use 'Send for Approval'.", order.name))
        action = super().action_quotation_send()
        if isinstance(action, dict) and action.get("res_model") == "mail.compose.message":
            action.setdefault("context", {})["default_partner_cc_allowed"] = True
        return action

    def action_confirm(self):
        for order in self.filtered(lambda o: o.state == "draft" and not o.env.su):
            if order.needs_approval:
                raise UserError(_("%s needs approval before it can be confirmed.", order.name))
        res = super().action_confirm()
        for order in self:
            if order.flow_stage_code in (False, "draft", "approval", "sent", "responded"):
                order._fahires_set_stage("responded", response_label="approved",
                                         response_date=fields.Datetime.now())
        return res

    def action_revise_quotation(self):
        """Bring a sent / responded quotation back to Draft QT for changes."""
        for order in self:
            if order.state == "sale":
                raise UserError(_("%s is already confirmed. Cancel it first to revise.", order.name))
            if order.state in ("sent", "cancel"):
                order.action_draft()
            order.write({
                "approval_state": "none",
                "approval_remarks": False,
                "response_label": False,
            })
            order._fahires_set_stage("draft")
            order.message_post(body=_("Quotation reopened for revision."))
        return True

    def action_close_archive(self):
        for order in self:
            if order.state not in ("cancel", "sale"):
                order._action_cancel()
            order._fahires_set_stage("archive")
            order.message_post(body=_("Deal closed and archived by %s.", self.env.user.name))
        return True

    def _fahires_customer_responded(self, label, remarks=None):
        vals = {"response_label": label, "response_date": fields.Datetime.now()}
        if remarks:
            vals["response_remarks"] = remarks
        for order in self:
            if order.flow_stage_code in ("archive", "delivery", "invoice", "payment"):
                order.with_context(fahires_flow_internal=True).write(vals)
            else:
                order._fahires_set_stage("responded", **vals)
            if order.user_id:
                order.activity_schedule(
                    "mail.mail_activity_data_todo",
                    summary=_("Customer %(label)s on %(qt)s",
                              label=dict(self._fields["response_label"].selection)[label], qt=order.name),
                    note=remarks or False,
                    user_id=order.user_id.id,
                )

    # ------------------------------------------------------------------ ORM hooks
    def write(self, vals):
        before = {o.id: o.state for o in self} if "state" in vals else {}
        reset_approval = (
            "order_line" in vals
            and not self.env.context.get("fahires_flow_internal")
        )
        res = super().write(vals)
        if before:
            for order in self:
                old = before.get(order.id)
                if old != order.state and order.state == "sent" and order.flow_stage_code in ("draft", "approval", False):
                    if order.approval_state != "approved" and order.is_approver:
                        order.with_context(fahires_flow_internal=True).write({
                            "approval_state": "approved",
                            "approval_user_id": self.env.user.id,
                            "approval_date": fields.Datetime.now(),
                        })
                    order._fahires_set_stage("sent", response_label=False)
        if "signed_on" in vals and vals.get("signed_on"):
            self._fahires_customer_responded("approved")
        if reset_approval:
            changed = self.filtered(lambda o: o.approval_state in ("pending", "approved") and o.state == "draft")
            if changed:
                changed.with_context(fahires_flow_internal=True).write({"approval_state": "none"})
                changed._fahires_set_stage("draft")
                for order in changed:
                    order._fahires_close_approval_activities(_("Quotation changed"))
                    order.message_post(body=_("Quotation lines changed after approval request: approval reset."))
        return res

    def message_post(self, **kwargs):
        message = super().message_post(**kwargs)
        if (
            len(self) == 1
            and message
            and message.message_type in ("comment", "email")
            and self.flow_stage_code in ("sent", "responded")
            and self.state in ("sent", "draft")
            and not self.env.context.get("fahires_flow_internal")
        ):
            author = message.author_id
            is_customer = author and (
                not author.user_ids or all(u.share for u in author.user_ids)
            )
            if is_customer and author.commercial_partner_id == self.partner_id.commercial_partner_id:
                text = html2plaintext(message.body or "").strip()
                self._fahires_customer_responded("remarks", text or _("(attachment)"))
        return message
