from odoo import _, models

PAID_STATES = ("paid", "in_payment", "reversed")


class AccountMove(models.Model):
    _inherit = "account.move"

    def _fahires_orders(self):
        return self.filtered(lambda m: m.move_type == "out_invoice").invoice_line_ids.sale_line_ids.order_id

    def _fahires_sync_order_stages(self):
        """Pending Invoice -> Pending Payment (credit) or Archive (paid); Pending Payment -> Archive when paid."""
        for order in self._fahires_orders().sudo():
            if order.flow_stage_code not in ("responded", "delivery", "invoice", "payment"):
                continue
            invoices = order.invoice_ids.filtered(lambda m: m.move_type == "out_invoice" and m.state == "posted")
            if not invoices:
                continue
            if order.invoice_status == "to invoice":
                continue  # still something left to invoice
            if all(inv.payment_state in PAID_STATES for inv in invoices):
                if order.flow_stage_code != "archive":
                    order._fahires_set_stage("archive")
                    order.message_post(body=_("Invoice(s) fully paid - deal archived."))
            elif order.flow_stage_code in ("delivery", "invoice", "responded"):
                order._fahires_set_stage("payment")

    def _post(self, soft=True):
        posted = super()._post(soft=soft)
        posted._fahires_sync_order_stages()
        return posted

    def _invoice_paid_hook(self):
        res = super()._invoice_paid_hook()
        self._fahires_sync_order_stages()
        return res
