from odoo import api, fields, models

DOCUMENT_TYPES = [
    ("sale", "Quotation"),
    ("invoice", "Customer Invoice"),
    ("purchase", "Purchase Order"),
]


class ApprovalRule(models.Model):
    _name = "fahires.approval.rule"
    _description = "Approval Rule"
    _order = "document_type, min_amount desc, id"

    name = fields.Char(required=True)
    active = fields.Boolean(default=True)
    document_type = fields.Selection(DOCUMENT_TYPES, required=True, default="sale")
    company_id = fields.Many2one("res.company", required=True, default=lambda s: s.env.company)
    currency_id = fields.Many2one(related="company_id.currency_id")
    min_amount = fields.Monetary(
        "Applies from amount",
        currency_field="currency_id",
        help="The rule applies to documents with a total equal to or above this amount. "
        "Use 0 to require approval for every document.",
    )
    approver_ids = fields.Many2many(
        "res.users",
        "fahires_approval_rule_users_rel",
        "rule_id",
        "user_id",
        string="Authorized Approvers",
        required=True,
        domain=[("share", "=", False)],
    )
    note = fields.Text("Instructions")

    @api.model
    def _get_rule(self, document_type, amount, company=None):
        company = company or self.env.company
        return self.search([
            ("document_type", "=", document_type),
            ("company_id", "=", company.id),
            ("min_amount", "<=", amount or 0.0),
        ], order="min_amount desc, id", limit=1)
