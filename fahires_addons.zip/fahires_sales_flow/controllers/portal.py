from odoo import http
from odoo.http import request

from odoo.addons.sale.controllers.portal import CustomerPortal


class FahiresSalePortal(CustomerPortal):

    @http.route()
    def portal_quote_decline(self, order_id, access_token=None, decline_message=None, **kwargs):
        response = super().portal_quote_decline(
            order_id, access_token=access_token, decline_message=decline_message, **kwargs
        )
        order = request.env["sale.order"].sudo().browse(order_id).exists()
        if order and order.state == "cancel" and decline_message:
            order._fahires_customer_responded("rejected", decline_message)
        return response
