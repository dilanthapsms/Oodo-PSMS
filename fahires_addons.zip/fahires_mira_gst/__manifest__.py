{
    "name": "MIRA GST Statements (Maldives)",
    "version": "20.0.1.0.0",
    "category": "Accounting/Localizations",
    "summary": "Export MIRA Input Tax and Output Tax Statements (v25.1) as Excel",
    "description": """
Generates the Maldives Inland Revenue Authority (MIRA) GST statements in the
MIRAconnect upload format (v25.1):

* Input Tax Statement  - from posted vendor bills / refunds
* Output Tax Statement - TaxInvoices sheet (customer invoices) and
  OtherTransactions sheet (POS / cash sales without a tax invoice)
""",
    "author": "Fahires",
    "license": "LGPL-3",
    "depends": ["account"],
    "data": [
        "security/ir.access.csv",
        "views/account_tax_views.xml",
        "views/res_company_views.xml",
        "wizard/mira_gst_wizard_views.xml",
    ],
    "installable": True,
    "application": False,
}
