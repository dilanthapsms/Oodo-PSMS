import base64
import io
from collections import defaultdict
from datetime import date

from dateutil.relativedelta import relativedelta

import xlsxwriter

from odoo import _, api, fields, models
from odoo.exceptions import UserError

INPUT_RATES = [6, 8, 12, 16, 17]
OUTPUT_COLS = ["standard", "zero", "exempt", "out_of_scope"]


class MiraGstWizard(models.TransientModel):
    _name = "fahires.mira.gst.wizard"
    _description = "MIRA GST Statement Export"

    def _default_date_from(self):
        today = fields.Date.context_today(self)
        first = today.replace(day=1)
        # previous month by default (the period normally being filed)
        prev_last = first - relativedelta(days=1)
        return prev_last.replace(day=1)

    def _default_date_to(self):
        today = fields.Date.context_today(self)
        return today.replace(day=1) - relativedelta(days=1)

    company_id = fields.Many2one("res.company", required=True, default=lambda s: s.env.company)
    date_from = fields.Date(required=True, default=_default_date_from)
    date_to = fields.Date(required=True, default=_default_date_to)
    statement = fields.Selection(
        [("input", "Input Tax Statement"), ("output", "Output Tax Statement")],
        required=True,
        default="output",
    )
    activity_no = fields.Char(
        "Taxable Activity No.",
        compute="_compute_activity_no",
        store=True,
        readonly=False,
    )
    file_data = fields.Binary(readonly=True, attachment=False)
    file_name = fields.Char(readonly=True)
    line_count = fields.Integer(readonly=True)

    @api.depends("company_id")
    def _compute_activity_no(self):
        for wiz in self:
            wiz.activity_no = wiz.company_id.mira_taxable_activity_no

    # ------------------------------------------------------------------ helpers
    @staticmethod
    def _round(value):
        return round(value or 0.0, 2)

    def _tax_category(self, taxes):
        """Return the MIRA category of a line from its taxes."""
        if not taxes:
            return "out_of_scope"
        cats = set(taxes.mapped("mira_category")) - {False}
        for cat in ("standard", "zero", "exempt", "out_of_scope"):
            if cat in cats:
                return cat
        return "standard" if any(taxes.mapped("amount")) else "zero"

    def _base_domain(self):
        return [
            ("company_id", "=", self.company_id.id),
            ("parent_state", "=", "posted"),
            ("date", ">=", self.date_from),
            ("date", "<=", self.date_to),
        ]

    # ------------------------------------------------------------------ output
    def _get_output_data(self):
        """Tax invoices (customers with a TIN) and other transactions totals."""
        lines = self.env["account.move.line"].search(
            self._base_domain() + [("account_id.internal_group", "=", "income"),
                                   ("display_type", "not in", ("line_section", "line_note"))]
        )
        invoices = defaultdict(lambda: dict.fromkeys(OUTPUT_COLS, 0.0))
        other = dict.fromkeys(OUTPUT_COLS, 0.0)
        for line in lines:
            amount = -line.balance  # income is credit -> positive
            cat = self._tax_category(line.tax_ids)
            move = line.move_id
            if move.move_type in ("out_invoice", "out_refund") and move.partner_id.commercial_partner_id.vat:
                invoices[move][cat] += amount
            else:
                other[cat] += amount
        rows = []
        for move in sorted(invoices, key=lambda m: (m.invoice_date or m.date, m.name)):
            partner = move.partner_id.commercial_partner_id
            vals = invoices[move]
            rows.append([
                partner.vat or "",
                partner.name or "",
                move.name,
                move.invoice_date or move.date,
                self._round(vals["standard"]),
                self._round(vals["zero"]),
                self._round(vals["exempt"]),
                self._round(vals["out_of_scope"]),
                self.activity_no or "",
            ])
        other_row = None
        if any(self._round(v) for v in other.values()):
            other_row = [
                self.activity_no or "",
                self._round(other["standard"]),
                self._round(other["zero"]),
                self._round(other["exempt"]),
                self._round(other["out_of_scope"]),
            ]
        return rows, other_row

    # ------------------------------------------------------------------ input
    def _get_input_data(self):
        moves = self.env["account.move"].search([
            ("company_id", "=", self.company_id.id),
            ("state", "=", "posted"),
            ("move_type", "in", ("in_invoice", "in_refund", "in_receipt")),
            ("date", ">=", self.date_from),
            ("date", "<=", self.date_to),
        ], order="invoice_date, date, name")
        rows = []
        for move in moves:
            sign = -1 if move.move_type == "in_refund" else 1
            gst = dict.fromkeys(INPUT_RATES, 0.0)
            for tline in move.line_ids.filtered(lambda l: l.display_type == "tax" and l.tax_line_id):
                rate = int(round(tline.tax_line_id.amount))
                if rate in gst:
                    gst[rate] += abs(tline.balance) * sign
            if not any(self._round(v) for v in gst.values()):
                continue
            product_lines = move.invoice_line_ids.filtered(lambda l: l.display_type == "product")
            capital = any(
                l.account_id.account_type in ("asset_fixed", "asset_non_current") for l in product_lines
            )
            partner = move.partner_id.commercial_partner_id
            rows.append([
                len(rows) + 1,
                partner.vat or "",
                partner.name or "",
                move.ref or move.name,
                move.invoice_date or move.date,
                self._round(abs(move.amount_untaxed_signed) * sign),
                *[self._round(gst[r]) for r in INPUT_RATES],
                self.activity_no or "",
                "Capital" if capital else "Revenue",
            ])
        return rows

    # ------------------------------------------------------------------ export
    def action_export(self):
        self.ensure_one()
        if self.date_from > self.date_to:
            raise UserError(_("The start date must be before the end date."))
        if not self.activity_no:
            raise UserError(_(
                "Please enter your MIRA Taxable Activity No. (also settable on the company)."
            ))
        if not self.company_id.mira_taxable_activity_no:
            self.company_id.mira_taxable_activity_no = self.activity_no

        buf = io.BytesIO()
        wb = xlsxwriter.Workbook(buf, {"in_memory": True})
        head = wb.add_format({"bold": True, "bg_color": "#D9E1F2", "border": 1, "text_wrap": True,
                              "valign": "top"})
        datef = wb.add_format({"num_format": "dd/mm/yyyy"})
        num = wb.add_format({"num_format": "#,##0.00"})
        text = wb.add_format({"num_format": "@"})

        def write_rows(ws, headers, rows, widths, date_cols=(), num_cols=(), text_cols=()):
            for c, h in enumerate(headers):
                ws.write(0, c, h, head)
                ws.set_column(c, c, widths[c])
            ws.set_row(0, 45)
            for r, row in enumerate(rows, start=1):
                for c, v in enumerate(row):
                    if c in date_cols and isinstance(v, date):
                        ws.write_datetime(r, c, v, datef)
                    elif c in num_cols:
                        ws.write_number(r, c, v or 0.0, num)
                    elif c in text_cols:
                        ws.write_string(r, c, str(v or ""), text)
                    else:
                        ws.write(r, c, v)
            ws.freeze_panes(1, 0)

        period = f"{self.date_from:%Y%m%d}-{self.date_to:%Y%m%d}"
        if self.statement == "output":
            rows, other = self._get_output_data()
            ws = wb.add_worksheet("TaxInvoices")
            write_rows(
                ws,
                ["Customer TIN", "Customer Name", "Invoice No.", "Invoice Date",
                 "Value of Supplies Subject to GST at 8% or 17% (excluding GST)",
                 "Value of Zero-Rated Supplies", "Value of Exempt Supplies",
                 "Value of Out-of-Scope Supplies", "Your Taxable Activity No."],
                rows, [18, 34, 18, 13, 22, 18, 18, 18, 22],
                date_cols=(3,), num_cols=(4, 5, 6, 7), text_cols=(0, 1, 2, 8),
            )
            ws2 = wb.add_worksheet("OtherTransactions")
            write_rows(
                ws2,
                ["Your Taxable Activity No.",
                 "Value of Supplies Subject to GST at 8% or 17% (excluding GST)",
                 "Value of Zero-Rated Supplies", "Value of Exempt Supplies",
                 "Value of Out-of-Scope Supplies"],
                [other] if other else [], [22, 22, 18, 18, 18],
                num_cols=(1, 2, 3, 4), text_cols=(0,),
            )
            count = len(rows) + (1 if other else 0)
            name = f"MIRA_Output_Tax_Statement_{period}.xlsx"
        else:
            rows = self._get_input_data()
            ws = wb.add_worksheet("Sheet1")
            write_rows(
                ws,
                ["#", "Supplier TIN", "Supplier Name", "Supplier Invoice Number", "Invoice Date",
                 "Invoice Total (excluding GST)", "GST Charged at 6%", "GST Charged at 8%",
                 "GST Charged at 12%", "GST Charged at 16%", "GST Charged at 17%",
                 "Your Taxable Activity Number", "Revenue / Capital"],
                rows, [6, 18, 34, 22, 13, 18, 14, 14, 14, 14, 14, 22, 14],
                date_cols=(4,), num_cols=(5, 6, 7, 8, 9, 10), text_cols=(1, 2, 3, 11, 12),
            )
            count = len(rows)
            name = f"MIRA_Input_Tax_Statement_{period}.xlsx"
        wb.close()

        self.write({
            "file_data": base64.b64encode(buf.getvalue()).decode(),
            "file_name": name,
            "line_count": count,
        })
        return {
            "type": "ir.actions.act_url",
            "url": f"/web/content/{self._name}/{self.id}/file_data/{name}?download=true",
            "target": "self",
        }
