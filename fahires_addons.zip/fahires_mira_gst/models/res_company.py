from odoo import fields, models


class ResCompany(models.Model):
    _inherit = "res.company"

    mira_taxable_activity_no = fields.Char(
        string="MIRA Taxable Activity No.",
        help="GST taxable activity number registered with MIRA (e.g. 1234567GST501). "
        "Printed on every line of the Input/Output Tax Statements.",
    )
