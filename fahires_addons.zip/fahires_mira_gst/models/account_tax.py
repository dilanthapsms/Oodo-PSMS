from odoo import api, fields, models

MIRA_CATEGORIES = [
    ("standard", "Standard-rated (6/8/12/16/17%)"),
    ("zero", "Zero-rated"),
    ("exempt", "Exempt"),
    ("out_of_scope", "Out of scope"),
]


class AccountTax(models.Model):
    _inherit = "account.tax"

    mira_category = fields.Selection(
        MIRA_CATEGORIES,
        string="MIRA GST Category",
        compute="_compute_mira_category",
        store=True,
        readonly=False,
        help="How amounts with this tax are reported on the MIRA Input/Output Tax Statements.",
    )

    @api.depends("amount", "name")
    def _compute_mira_category(self):
        for tax in self:
            if tax.mira_category:
                continue
            name = (tax.name or "").lower()
            if "exempt" in name:
                tax.mira_category = "exempt"
            elif "scope" in name:
                tax.mira_category = "out_of_scope"
            elif not tax.amount:
                tax.mira_category = "zero"
            else:
                tax.mira_category = "standard"
