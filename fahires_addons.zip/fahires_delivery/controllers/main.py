import base64

from odoo import _, http
from odoo.exceptions import UserError
from odoo.http import request
from odoo.tools import consteq

MAX_FILE_SIZE = 15 * 1024 * 1024  # 15 MB per file


class DeliveryStatusController(http.Controller):

    def _get_delivery(self, delivery_id, token):
        delivery = request.env["fahires.delivery"].sudo().browse(delivery_id).exists()
        if not delivery or not token or not delivery.access_token or not consteq(delivery.access_token, token):
            return None
        return delivery

    @http.route("/delivery/status/<int:delivery_id>", type="http", auth="public", website=False,
                methods=["GET"], sitemap=False)
    def delivery_status_page(self, delivery_id, token=None, message=None, error=None, **kw):
        delivery = self._get_delivery(delivery_id, token)
        if not delivery:
            return request.not_found()
        return request.render("fahires_delivery.delivery_status_page", {
            "delivery": delivery,
            "token": token,
            "message": message,
            "error": error,
            "res_company": delivery.company_id,
        })

    @http.route("/delivery/status/<int:delivery_id>/update", type="http", auth="public", website=False,
                methods=["POST"], sitemap=False)
    def delivery_status_update(self, delivery_id, token=None, status=None, received_by=None,
                               note=None, updated_by=None, **kw):
        delivery = self._get_delivery(delivery_id, token)
        if not delivery:
            return request.not_found()
        files = request.httprequest.files.getlist("attachments")
        attachments = request.env["ir.attachment"].sudo()
        for f in files:
            if not f or not f.filename:
                continue
            data = f.read()
            if len(data) > MAX_FILE_SIZE:
                return self._redirect(delivery, token, error=_("File %s is larger than 15 MB.", f.filename))
            attachments |= attachments.create({
                "name": f.filename,
                "raw": data,
                "res_model": "fahires.delivery",
                "res_id": delivery.id,
                "mimetype": f.mimetype,
            })
        author = (updated_by or "").strip() or _("Delivery staff (QR)")
        try:
            if status in ("transit", "delivered", "failed"):
                delivery._set_status(status, note=(note or "").strip() or None, attachments=attachments,
                                     received_by=(received_by or "").strip() or None, author_name=author)
                msg = _("Status updated to %s.", delivery.stage_id.name)
            elif attachments or note:
                delivery.message_post(body=_("%(who)s: %(note)s", who=author, note=note or _("attachment added")),
                                      attachment_ids=attachments.ids)
                msg = _("Saved.")
            else:
                return self._redirect(delivery, token, error=_("Nothing to update."))
        except UserError as e:
            request.env.cr.rollback()
            return self._redirect(delivery, token, error=str(e))
        return self._redirect(delivery, token, message=msg)

    def _redirect(self, delivery, token, message=None, error=None):
        from urllib.parse import urlencode
        params = {"token": token}
        if message:
            params["message"] = message
        if error:
            params["error"] = error
        return request.redirect(f"/delivery/status/{delivery.id}?{urlencode(params)}", local=True)
