from datetime import datetime, time, timedelta

from odoo import _, api, fields, models
from odoo.exceptions import UserError

from ..models.delivery import DELIVERY_MODES, FOLLOWME_URL


class ArrangeDeliveryWizard(models.TransientModel):
    _name = "fahires.arrange.delivery.wizard"
    _description = "Arrange Delivery"

    def _default_schedule(self):
        tomorrow = fields.Date.context_today(self) + timedelta(days=1)
        return datetime.combine(tomorrow, time(4, 0))  # 09:00 Maldives time (UTC+5)

    order_id = fields.Many2one("sale.order", required=True)
    partner_id = fields.Many2one(related="order_id.partner_id")
    scheduled_datetime = fields.Datetime("Delivery Date & Time", required=True, default=_default_schedule)
    delivery_mode = fields.Selection(DELIVERY_MODES, "Mode of Delivery", required=True, default="van")
    contact_name = fields.Char("Contact Person", compute="_compute_contact", store=True, readonly=False)
    contact_phone = fields.Char("Contact Phone", compute="_compute_contact", store=True, readonly=False)
    delivery_address = fields.Text("Delivery Address", compute="_compute_contact", store=True, readonly=False)
    vehicle_no = fields.Char("Vehicle No.")
    driver_name = fields.Char("Driver / Delivered By")
    boat_name = fields.Char("Boat Name")
    boat_contact_name = fields.Char("Boat Contact Person")
    boat_contact_phone = fields.Char("Boat Contact Phone")
    followme_url = fields.Char("FollowMe Tracking Link", default=FOLLOWME_URL)
    flight_details = fields.Char("Flight / Airway Bill")
    notes = fields.Text("Delivery Instructions")

    @api.depends("order_id")
    def _compute_contact(self):
        for wiz in self:
            ship = wiz.order_id.partner_shipping_id or wiz.order_id.partner_id
            contact = wiz.order_id.partner_id
            wiz.contact_name = contact.name if not contact.is_company else (contact.child_ids[:1].name or contact.name)
            wiz.contact_phone = contact.phone or ship.phone
            wiz.delivery_address = ship._display_address(without_name=True).strip() if ship else False

    def action_create_delivery(self):
        self.ensure_one()
        order = self.order_id
        if not order.can_arrange_delivery:
            raise UserError(_("Delivery can only be arranged for customer-approved deals without an open delivery."))
        if order.state != "sale":
            order.action_confirm()
        if self.delivery_mode == "boat" and not self.boat_name:
            raise UserError(_("Please enter the boat name for boat deliveries."))
        picking = order.picking_ids.filtered(
            lambda p: p.picking_type_code == "outgoing" and p.state not in ("done", "cancel")
        )[:1]
        lines = []
        for line in order.order_line.filtered(lambda l: not l.display_type and l.product_id.type != "service"):
            lines.append((0, 0, {
                "product_id": line.product_id.id,
                "name": line.product_id.display_name,
                "quantity": line.product_uom_qty - line.qty_delivered,
                "uom_name": line.product_uom_id.name,
            }))
        delivery = self.env["fahires.delivery"].create({
            "sale_order_id": order.id,
            "order_ref": order.name,
            "partner_id": order.partner_id.id,
            "company_id": order.company_id.id,
            "currency_id": order.currency_id.id,
            "amount_total": order.amount_total,
            "picking_id": picking.id,
            "scheduled_datetime": self.scheduled_datetime,
            "delivery_mode": self.delivery_mode,
            "contact_name": self.contact_name,
            "contact_phone": self.contact_phone,
            "delivery_address": self.delivery_address,
            "vehicle_no": self.vehicle_no,
            "driver_name": self.driver_name,
            "boat_name": self.boat_name,
            "boat_contact_name": self.boat_contact_name,
            "boat_contact_phone": self.boat_contact_phone,
            "followme_url": self.followme_url,
            "flight_details": self.flight_details,
            "notes": self.notes,
            "line_ids": lines,
        })
        order._fahires_set_stage("delivery")
        order.message_post(body=_("Delivery %(dn)s scheduled (%(mode)s).", dn=delivery.name,
                                  mode=dict(DELIVERY_MODES)[self.delivery_mode]))
        return {
            "type": "ir.actions.act_window",
            "res_model": "fahires.delivery",
            "res_id": delivery.id,
            "view_mode": "form",
            "views": [(False, "form")],
        }
