from odoo import fields, models


class DeliveryStatusWizard(models.TransientModel):
    _name = "fahires.delivery.status.wizard"
    _description = "Update Delivery Status"

    delivery_id = fields.Many2one("fahires.delivery", required=True)
    new_status = fields.Selection(
        [("transit", "Out for Delivery"), ("delivered", "Delivered"), ("failed", "Failed / Returned")],
        required=True, default="delivered",
    )
    received_by = fields.Char("Received By (Customer)")
    note = fields.Text("Note / Reason")
    attachment_ids = fields.Many2many("ir.attachment", string="Signed DN / Photos")

    def action_apply(self):
        self.ensure_one()
        self.delivery_id._set_status(
            self.new_status,
            note=self.note,
            attachments=self.attachment_ids,
            received_by=self.received_by,
        )
        return {"type": "ir.actions.act_window_close"}
