{
    "name": "Fahires Delivery",
    "version": "20.0.1.0.0",
    "category": "Inventory/Delivery",
    "summary": "Delivery notes (DN) with QR status updates, signed DN upload and customer notification",
    "description": """
* Delivery app with kanban dashboard (Scheduled, Out for Delivery, Delivered, Failed, Cancelled)
* DN number linked to the quotation / deal, scheduled date & time, delivery mode
  (Van, Boat, Air, Pickup), contact person, boat name & boat contact, FollowMe tracking link
* Order values visible only to the "Delivery: See Values" group
* Printable Delivery Note with a QR code: scanning it opens a mobile page to update the
  status and upload the signed DN (no login needed, secured by a private token)
* Delivered + signed DN: stock delivery validated, customer emailed automatically,
  deal moves to Pending Invoice
""",
    "author": "Fahires",
    "license": "LGPL-3",
    "depends": ["fahires_sales_flow", "sale_stock", "portal", "mail"],
    "data": [
        "security/delivery_security.xml",
        "security/ir.access.csv",
        "data/delivery_data.xml",
        "data/mail_template_data.xml",
        "report/delivery_report.xml",
        "wizard/arrange_delivery_wizard_views.xml",
        "wizard/delivery_status_wizard_views.xml",
        "views/delivery_views.xml",
        "views/sale_order_views.xml",
        "views/status_page_templates.xml",
        "views/menus.xml",
    ],
    "installable": True,
    "application": True,
}
