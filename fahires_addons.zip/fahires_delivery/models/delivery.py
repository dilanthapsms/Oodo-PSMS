import base64
import io
import uuid

import qrcode

from markupsafe import Markup

from odoo import _, api, fields, models
from odoo.exceptions import UserError

DELIVERY_MODES = [
    ("van", "Van"),
    ("boat", "Boat"),
    ("air", "Air"),
    ("pickup", "Customer Pickup"),
]
STAGE_CODES = [
    ("scheduled", "Scheduled"),
    ("transit", "Out for Delivery"),
    ("delivered", "Delivered"),
    ("failed", "Failed / Returned"),
    ("cancelled", "Cancelled"),
]
FOLLOWME_URL = "https://m.followme.mv"


class DeliveryStage(models.Model):
    _name = "fahires.delivery.stage"
    _description = "Delivery Stage"
    _order = "sequence, id"

    name = fields.Char(required=True, translate=True)
    code = fields.Selection(STAGE_CODES, required=True)
    sequence = fields.Integer(default=10)
    fold = fields.Boolean("Folded in Kanban")

    _code_unique = models.Constraint("UNIQUE(code)", "Each delivery status can only have one stage.")


class Delivery(models.Model):
    _name = "fahires.delivery"
    _description = "Delivery Note"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "scheduled_datetime desc, id desc"
    _rec_name = "name"

    name = fields.Char("DN Number", required=True, copy=False, readonly=True, default="/", index=True)
    stage_id = fields.Many2one(
        "fahires.delivery.stage", "Status", tracking=True, index=True, copy=False,
        default=lambda s: s._stage("scheduled"), group_expand="_read_group_stage_ids", ondelete="restrict",
    )
    stage_code = fields.Selection(related="stage_id.code", store=True, string="Status Code")
    color = fields.Integer(compute="_compute_color")

    sale_order_id = fields.Many2one("sale.order", "Quotation / Order", index=True, ondelete="restrict",
                                    groups="sales_team.group_sale_salesman")
    order_ref = fields.Char("QT Number", readonly=True, index=True)
    company_id = fields.Many2one("res.company", required=True, default=lambda s: s.env.company)
    currency_id = fields.Many2one("res.currency", readonly=True)
    partner_id = fields.Many2one("res.partner", "Customer", required=True, tracking=True)
    delivery_address = fields.Text("Delivery Address")
    picking_id = fields.Many2one("stock.picking", "Warehouse Delivery", readonly=True, copy=False)
    user_id = fields.Many2one("res.users", "Arranged By", default=lambda s: s.env.user, tracking=True)

    scheduled_datetime = fields.Datetime("Scheduled Date & Time", required=True, tracking=True)
    delivery_mode = fields.Selection(DELIVERY_MODES, "Mode of Delivery", required=True, default="van", tracking=True)
    contact_name = fields.Char("Contact Person")
    contact_phone = fields.Char("Contact Phone")
    vehicle_no = fields.Char("Vehicle No.")
    driver_name = fields.Char("Driver / Delivered By")
    boat_name = fields.Char("Boat Name", tracking=True)
    boat_contact_name = fields.Char("Boat Contact Person")
    boat_contact_phone = fields.Char("Boat Contact Phone")
    followme_url = fields.Char("FollowMe Tracking Link", default=FOLLOWME_URL)
    flight_details = fields.Char("Flight / Airway Bill")
    notes = fields.Text("Delivery Instructions")

    line_ids = fields.One2many("fahires.delivery.line", "delivery_id", "Items", copy=True)
    item_count = fields.Integer(compute="_compute_item_count")
    amount_total = fields.Monetary("Order Value", currency_field="currency_id", readonly=True,
                                   groups="fahires_delivery.group_delivery_values")

    access_token = fields.Char(copy=False, default=lambda s: uuid.uuid4().hex, groups="base.group_user")
    status_url = fields.Char("Status Update Link", compute="_compute_status_url", groups="base.group_user")
    delivered_datetime = fields.Datetime("Delivered On", readonly=True, copy=False, tracking=True)
    received_by = fields.Char("Received By (Customer)", copy=False, tracking=True)
    signed_dn_ids = fields.Many2many("ir.attachment", "fahires_delivery_signed_dn_rel", "delivery_id",
                                     "attachment_id", string="Signed DN", copy=False)
    has_signed_dn = fields.Boolean(compute="_compute_has_signed_dn", store=True)
    status_note = fields.Text("Last Status Note", readonly=True, copy=False)
    customer_notified = fields.Boolean(readonly=True, copy=False)

    # ------------------------------------------------------------------ helpers
    def _stage(self, code):
        return self.env["fahires.delivery.stage"].search([("code", "=", code)], limit=1)

    @api.model
    def _read_group_stage_ids(self, stages, domain):
        return self.env["fahires.delivery.stage"].search([])

    @api.depends("stage_code")
    def _compute_color(self):
        colors = {"scheduled": 0, "transit": 4, "delivered": 10, "failed": 1, "cancelled": 0}
        for rec in self:
            rec.color = colors.get(rec.stage_code, 0)

    @api.depends("line_ids")
    def _compute_item_count(self):
        for rec in self:
            rec.item_count = len(rec.line_ids)

    @api.depends("signed_dn_ids")
    def _compute_has_signed_dn(self):
        for rec in self:
            rec.has_signed_dn = bool(rec.signed_dn_ids)

    def _compute_status_url(self):
        base = self.env["ir.config_parameter"].sudo().get_str("web.base.url") or ""
        for rec in self:
            rec.status_url = f"{base}/delivery/status/{rec.id}?token={rec.sudo().access_token}" if rec.id else False

    def _qr_data_uri(self):
        """QR code (PNG data URI) pointing to the public status-update page."""
        self.ensure_one()
        img = qrcode.make(self.sudo().status_url, box_size=8, border=2)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name", "/") == "/":
                vals["name"] = self.env["ir.sequence"].next_by_code("fahires.delivery") or "/"
        return super().create(vals_list)

    def write(self, vals):
        res = super().write(vals)
        if "signed_dn_ids" in vals and not self.env.context.get("fahires_dn_auto"):
            # Attaching the signed DN = delivered
            to_deliver = self.filtered(lambda d: d.signed_dn_ids and d.stage_code in ("scheduled", "transit"))
            if to_deliver:
                to_deliver.with_context(fahires_dn_auto=True)._set_status(
                    "delivered", note=_("Signed DN attached - marked as delivered automatically."))
        return res

    # ------------------------------------------------------------------ actions
    def action_open_followme(self):
        self.ensure_one()
        return {"type": "ir.actions.act_url", "url": self.followme_url or FOLLOWME_URL, "target": "new"}

    def action_print_dn(self):
        return self.env.ref("fahires_delivery.action_report_delivery_note").report_action(self)

    def action_mark_transit(self):
        self._set_status("transit")

    def action_open_status_wizard(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Update Delivery Status"),
            "res_model": "fahires.delivery.status.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {"default_delivery_id": self.id,
                        "default_new_status": self.env.context.get("target_status", "delivered")},
        }

    def action_cancel(self):
        self._set_status("cancelled", note=_("Cancelled by %s", self.env.user.name))

    def action_reschedule(self):
        for rec in self:
            if rec.stage_code not in ("failed", "cancelled"):
                raise UserError(_("Only failed or cancelled deliveries can be rescheduled."))
        self._set_status("scheduled", note=_("Rescheduled"))

    # ------------------------------------------------------------------ status engine
    def _set_status(self, code, note=None, attachments=None, received_by=None, author_name=None):
        """Single entry point for every status change (backend buttons and QR page)."""
        stage = self._stage(code)
        if not stage:
            raise UserError(_("Unknown delivery status %s", code))
        attachments = attachments or self.env["ir.attachment"]
        for rec in self:
            if rec.stage_code == "delivered" and code != "delivered":
                raise UserError(_("%s is already delivered.", rec.name))
            if code == "delivered" and not (attachments or rec.signed_dn_ids):
                raise UserError(_("Please attach the signed Delivery Note to mark %s as delivered.", rec.name))
            if code == "failed" and not note:
                raise UserError(_("Please enter the reason the delivery failed."))
            vals = {"stage_id": stage.id}
            if note:
                vals["status_note"] = note
            if received_by:
                vals["received_by"] = received_by
            if attachments:
                attachments.sudo().write({"res_model": rec._name, "res_id": rec.id})
                vals["signed_dn_ids"] = [(4, a.id) for a in attachments]
            if code == "delivered":
                vals["delivered_datetime"] = fields.Datetime.now()
            rec.sudo().write(vals)

            label = dict(STAGE_CODES)[code]
            who = author_name or self.env.user.name
            body = Markup("<b>%s</b> %s") % (_("Status: %s", label), _("(updated by %s)", who))
            if received_by:
                body += Markup("<br/>%s") % _("Received by: %s", received_by)
            if note:
                body += Markup("<br/>%s") % note
            rec.sudo().message_post(body=body, attachment_ids=attachments.ids)
            rec._propagate_to_order(code, body, attachments)
            if code == "delivered":
                rec._validate_stock_delivery()
                rec._notify_customer_delivered()
        return True

    def _propagate_to_order(self, code, body, attachments):
        self.ensure_one()
        order = self.sudo().sale_order_id
        if not order:
            return
        order.message_post(
            body=Markup("<b>%s %s</b><br/>") % (_("Delivery"), self.name) + body,
            attachment_ids=attachments.copy({"res_model": "sale.order", "res_id": order.id}).ids if attachments else [],
            subtype_xmlid="mail.mt_note",
        )
        if code == "delivered":
            open_dns = order.fahires_delivery_ids.filtered(lambda d: d.stage_code in ("scheduled", "transit"))
            if not open_dns and order.flow_stage_code in (False, "draft", "approval", "sent", "responded", "delivery"):
                order._fahires_set_stage("invoice")
        elif code == "scheduled" and order.flow_stage_code in ("responded", "delivery"):
            order._fahires_set_stage("delivery")
        elif code == "failed" and order.user_id:
            order.activity_schedule(
                "mail.mail_activity_data_todo",
                summary=_("Delivery %s failed - reschedule", self.name),
                note=self.status_note,
                user_id=order.user_id.id,
            )

    def _validate_stock_delivery(self):
        """Reduce stock: validate the outgoing warehouse picking of the order."""
        self.ensure_one()
        picking = self.sudo().picking_id
        if not picking or picking.state in ("done", "cancel"):
            return
        try:
            with self.env.cr.savepoint():
                if picking.state == "draft":
                    picking.action_confirm()
                picking.action_assign()
                for move in picking.move_ids.filtered(lambda m: m.state not in ("done", "cancel")):
                    move.quantity = move.product_uom_qty
                    move.picked = True
                res = picking.with_context(
                    skip_backorder=True,
                    picking_ids_not_to_backorder=picking.ids,
                    skip_sms=True,
                ).button_validate()
                if isinstance(res, dict):
                    raise UserError(_("Warehouse validation needs manual action."))
            self.sudo().message_post(body=_("Stock delivery %s validated.", picking.name))
        except Exception as e:  # keep the delivery status; warehouse can validate manually
            self.sudo().message_post(
                body=_("Stock delivery %(p)s could not be validated automatically: %(e)s", p=picking.name, e=e))
            if self.user_id:
                self.sudo().activity_schedule(
                    "mail.mail_activity_data_todo",
                    summary=_("Validate warehouse delivery %s", picking.name),
                    user_id=self.user_id.id,
                )

    def _notify_customer_delivered(self):
        self.ensure_one()
        template = self.env.ref("fahires_delivery.mail_template_delivered", raise_if_not_found=False)
        if not template or not self.partner_id.email:
            self.sudo().message_post(body=_("Customer not emailed: no email address on %s.", self.partner_id.name))
            return
        template.sudo().send_mail(
            self.id,
            force_send=False,
            email_values={"attachment_ids": [(4, a.id) for a in self.signed_dn_ids]},
        )
        self.sudo().customer_notified = True


class DeliveryLine(models.Model):
    _name = "fahires.delivery.line"
    _description = "Delivery Note Item"
    _order = "sequence, id"

    delivery_id = fields.Many2one("fahires.delivery", required=True, ondelete="cascade", index=True)
    sequence = fields.Integer(default=10)
    product_id = fields.Many2one("product.product", "Product")
    name = fields.Char("Description", required=True)
    quantity = fields.Float("Quantity", digits="Product Unit")
    uom_name = fields.Char("Unit")
