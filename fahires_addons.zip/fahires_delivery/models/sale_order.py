from odoo import _, api, fields, models
from odoo.exceptions import UserError

from .delivery import DELIVERY_MODES


class SaleOrder(models.Model):
    _inherit = "sale.order"

    fahires_delivery_ids = fields.One2many("fahires.delivery", "sale_order_id", "Delivery Notes")
    fahires_delivery_count = fields.Integer(compute="_compute_fahires_delivery")
    dn_id = fields.Many2one("fahires.delivery", "Latest DN", compute="_compute_fahires_delivery")
    dn_number = fields.Char("DN Number", compute="_compute_fahires_delivery")
    dn_scheduled = fields.Datetime("Delivery Scheduled", compute="_compute_fahires_delivery")
    dn_mode = fields.Selection(DELIVERY_MODES, "Delivery Mode", compute="_compute_fahires_delivery")
    dn_status = fields.Char("DN Status", compute="_compute_fahires_delivery")
    dn_status_code = fields.Char(compute="_compute_fahires_delivery")
    can_arrange_delivery = fields.Boolean(compute="_compute_fahires_delivery")

    @api.depends("fahires_delivery_ids.stage_id", "fahires_delivery_ids.scheduled_datetime",
                 "state", "flow_stage_code", "response_label")
    def _compute_fahires_delivery(self):
        for order in self:
            dns = order.fahires_delivery_ids.filtered(lambda d: d.stage_code != "cancelled").sorted("id")
            last = dns[-1:] if dns else order.fahires_delivery_ids.sorted("id")[-1:]
            order.fahires_delivery_count = len(order.fahires_delivery_ids)
            order.dn_id = last
            order.dn_number = last.name if last else False
            order.dn_scheduled = last.scheduled_datetime if last else False
            order.dn_mode = last.delivery_mode if last else False
            order.dn_status = last.stage_id.name if last else False
            order.dn_status_code = last.stage_code if last else False
            open_dn = dns.filtered(lambda d: d.stage_code in ("scheduled", "transit"))
            order.can_arrange_delivery = (
                not open_dn
                and order.state in ("sent", "sale")
                and order.response_label == "approved"
                and order.flow_stage_code in ("responded", "delivery")
            )

    def action_arrange_delivery(self):
        self.ensure_one()
        if not self.can_arrange_delivery:
            raise UserError(_("Delivery can be arranged once the customer has approved the quotation."))
        return {
            "type": "ir.actions.act_window",
            "name": _("Arrange Delivery - %s", self.name),
            "res_model": "fahires.arrange.delivery.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {"default_order_id": self.id},
        }

    def action_view_fahires_deliveries(self):
        self.ensure_one()
        action = self.env["ir.actions.act_window"]._for_xml_id("fahires_delivery.action_delivery_all")
        action["domain"] = [("sale_order_id", "=", self.id)]
        action["context"] = {"create": False}
        if self.fahires_delivery_count == 1:
            action.update({"view_mode": "form", "views": [(False, "form")], "res_id": self.fahires_delivery_ids.id})
        return action
