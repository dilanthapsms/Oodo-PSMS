from odoo import fields, models

CUSTOMER_TYPES = [
    ("government", "Government"),
    ("semi_government", "Semi-Government"),
    ("private", "Private"),
]


class ResPartner(models.Model):
    _inherit = "res.partner"

    customer_type = fields.Selection(CUSTOMER_TYPES, string="Customer Type", tracking=True, index=True)
    industry_id = fields.Many2one(string="Sector")


class SaleOrder(models.Model):
    _inherit = "sale.order"

    customer_type = fields.Selection(
        related="partner_id.commercial_partner_id.customer_type", store=True, string="Customer Type")
    customer_sector_id = fields.Many2one(
        related="partner_id.commercial_partner_id.industry_id", store=True, string="Sector")


class AccountMove(models.Model):
    _inherit = "account.move"

    customer_type = fields.Selection(
        related="commercial_partner_id.customer_type", store=True, string="Customer Type")
    customer_sector_id = fields.Many2one(
        related="commercial_partner_id.industry_id", store=True, string="Sector")
