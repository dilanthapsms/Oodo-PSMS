{
    "name": "Fahires Customer Profile",
    "version": "20.0.1.0.0",
    "category": "Sales/Sales",
    "summary": "Customer type (Government / Semi-Government / Private) and sector on contacts, orders and invoices",
    "author": "Fahires",
    "license": "LGPL-3",
    "depends": ["sale_management", "account"],
    "data": [
        "data/sector_data.xml",
        "views/res_partner_views.xml",
        "views/sale_account_views.xml",
    ],
    "installable": True,
}
