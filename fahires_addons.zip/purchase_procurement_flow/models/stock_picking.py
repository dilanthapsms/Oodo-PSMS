from odoo import models


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    def _action_done(self):
        res = super()._action_done()
        orders = self.move_ids.purchase_line_id.order_id
        orders.filtered(
            lambda o: o.receipt_status == 'full' and o.procurement_stage in ('shipment', 'clearance')
        ).write({'procurement_stage': 'done'})
        return res
