from odoo import api, fields, models


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    # Allow choosing the currency on each quotation (default: pricelist / company currency = MVR)
    currency_id = fields.Many2one(readonly=False)
    exchange_rate_info = fields.Char(string='Exchange Rate', compute='_compute_exchange_rate_info')

    @api.depends('currency_id', 'company_id', 'date_order')
    def _compute_exchange_rate_info(self):
        for order in self:
            order.exchange_rate_info = order.currency_id._ppf_rate_label(order.company_id, order.date_order)


class AccountMove(models.Model):
    _inherit = 'account.move'

    exchange_rate_info = fields.Char(string='Exchange Rate', compute='_compute_exchange_rate_info')

    @api.depends('currency_id', 'company_id', 'invoice_date', 'date')
    def _compute_exchange_rate_info(self):
        for move in self:
            move.exchange_rate_info = move.currency_id._ppf_rate_label(
                move.company_id, move.invoice_date or move.date)


class SaleOrderCurrency(models.Model):
    _inherit = 'sale.order'

    @api.onchange('currency_id')
    def _onchange_currency_id_recompute_prices(self):
        # Re-price the lines in the newly selected currency (converted with the configured rate)
        if self.order_line and self.state == 'draft':
            self._recompute_prices()
