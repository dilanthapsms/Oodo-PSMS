from odoo import _, api, fields, models
from odoo.exceptions import UserError

PROCUREMENT_STAGES = [
    ('draft', 'Drafted Orders'),
    ('checking', 'Pending Checking'),
    ('approval', 'Pending Approval'),
    ('waiting_price', 'Waiting for Prices'),
    ('resend', 'Resend Vendor'),
    ('to_issue', 'Pending to Issue PO'),
    ('shipment', 'Pending Shipment'),
    ('clearance', 'Pending Clearance'),
    ('done', 'Completed'),
    ('cancel', 'Cancelled'),
]
# Columns always shown on the Kanban board (done / cancel only show when filtered in)
BOARD_STAGES = ['draft', 'checking', 'approval', 'waiting_price', 'resend',
                'to_issue', 'shipment', 'clearance']
VENDOR_EDITABLE_STAGES = ('waiting_price', 'resend')


class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    procurement_stage = fields.Selection(
        PROCUREMENT_STAGES, string='Procurement Stage', default='draft',
        required=True, copy=False, tracking=True, index=True,
        group_expand='_expand_procurement_stages')
    checked_by_id = fields.Many2one('res.users', string='Checked By', copy=False, readonly=True)
    checked_date = fields.Datetime(string='Checked On', copy=False, readonly=True)
    request_approved_by_id = fields.Many2one('res.users', string='Approved By', copy=False, readonly=True)
    request_approved_date = fields.Datetime(string='Approved On', copy=False, readonly=True)

    vendor_price_url = fields.Char(string='Vendor Price Link', compute='_compute_vendor_price_url')
    vendor_quote_submitted = fields.Boolean(string='Vendor Prices Submitted', copy=False, readonly=True)
    vendor_quote_date = fields.Datetime(string='Prices Submitted On', copy=False, readonly=True)
    vendor_quote_ref = fields.Char(string='Vendor Quotation No.', copy=False)
    vendor_lead_time = fields.Char(string='Vendor Delivery Time', copy=False)
    vendor_quote_validity = fields.Char(string='Vendor Quote Validity', copy=False)
    vendor_quote_note = fields.Text(string='Vendor Remarks', copy=False)

    shipment_ref = fields.Char(string='AWB / B/L No.', copy=False, tracking=True)
    shipment_eta = fields.Date(string='Shipment ETA', copy=False, tracking=True)
    clearance_ref = fields.Char(string='Customs Declaration No.', copy=False, tracking=True)

    exchange_rate_info = fields.Char(string='Exchange Rate', compute='_compute_exchange_rate_info')

    # ------------------------------------------------------------------
    # Compute
    # ------------------------------------------------------------------
    @api.model
    def _expand_procurement_stages(self, values, domain):
        return BOARD_STAGES

    def _compute_vendor_price_url(self):
        for order in self:
            if order.id and order.access_token:
                order.vendor_price_url = '%s/vendor/price-request/%s?access_token=%s' % (
                    order.get_base_url(), order.id, order.access_token)
            else:
                order.vendor_price_url = False

    @api.depends('currency_id', 'company_id', 'date_order')
    def _compute_exchange_rate_info(self):
        for order in self:
            order.exchange_rate_info = order.currency_id._ppf_rate_label(
                order.company_id, order.date_order)

    def _guess_procurement_stage(self):
        self.ensure_one()
        if self.state == 'cancel':
            return 'cancel'
        if self.state == 'purchase':
            if 'receipt_status' in self._fields and self.receipt_status == 'full':
                return 'done'
            return 'shipment'
        if self.state == 'to approve':
            return 'to_issue'
        if self.state == 'sent':
            return 'waiting_price'
        return 'draft'

    # ------------------------------------------------------------------
    # Workflow buttons
    # ------------------------------------------------------------------
    def _check_stage(self, allowed):
        for order in self:
            if order.procurement_stage not in allowed:
                raise UserError(_(
                    "%(order)s is in stage '%(stage)s'; this action is not possible from there.",
                    order=order.name,
                    stage=dict(PROCUREMENT_STAGES)[order.procurement_stage]))

    def action_ppf_submit_check(self):
        self._check_stage(('draft',))
        for order in self:
            if not order.order_line.filtered(lambda l: not l.display_type):
                raise UserError(_("Add at least one product to %s before submitting.", order.name))
        self.procurement_stage = 'checking'

    def action_ppf_mark_checked(self):
        self._check_stage(('checking',))
        self.write({
            'procurement_stage': 'approval',
            'checked_by_id': self.env.uid,
            'checked_date': fields.Datetime.now(),
        })

    def action_ppf_approve(self):
        self._check_stage(('approval',))
        self.write({
            'request_approved_by_id': self.env.uid,
            'request_approved_date': fields.Datetime.now(),
        })
        if len(self) == 1:
            return self.action_ppf_send_vendor()
        return True

    def action_ppf_reject(self):
        """Send back to draft from checking / approval."""
        self._check_stage(('checking', 'approval'))
        self.write({'procurement_stage': 'draft', 'checked_by_id': False, 'checked_date': False,
                    'request_approved_by_id': False, 'request_approved_date': False})

    def action_ppf_send_vendor(self):
        """Open the e-mail composer with the Order Request + price link."""
        self.ensure_one()
        if self.procurement_stage not in ('approval', 'waiting_price', 'resend'):
            raise UserError(_("The order request can only be sent once it is approved."))
        if not self.request_approved_by_id:
            raise UserError(_("The order request must be approved before sending it to the vendor."))
        self._portal_ensure_token()
        template = self.env.ref('purchase_procurement_flow.mail_template_order_request',
                                raise_if_not_found=False)
        compose_form = self.env.ref('mail.email_compose_message_wizard_form', raise_if_not_found=False)
        ctx = {
            'default_model': 'purchase.order',
            'default_res_ids': self.ids,
            'default_template_id': template.id if template else False,
            'default_composition_mode': 'comment',
            'email_notification_allow_footer': True,
            'force_email': True,
            'hide_mail_template_management_options': True,
            'mark_rfq_as_sent': True,
            'ppf_vendor_request': True,
            'model_description': _('Order Request'),
        }
        return {
            'name': _('Send Order Request'),
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'views': [(compose_form.id if compose_form else False, 'form')],
            'target': 'new',
            'context': ctx,
        }

    def action_ppf_request_revision(self):
        """Prices need to be corrected / re-quoted by the vendor."""
        self._check_stage(('waiting_price', 'to_issue'))
        self.write({'procurement_stage': 'resend', 'vendor_quote_submitted': False})

    def action_ppf_prices_received(self):
        """Buyer entered the prices manually (vendor replied by e-mail)."""
        self._check_stage(VENDOR_EDITABLE_STAGES)
        self._ppf_check_prices()
        self.write({'procurement_stage': 'to_issue', 'vendor_quote_date': fields.Datetime.now()})

    def action_ppf_issue_po(self):
        self._check_stage(('to_issue',))
        self._ppf_check_prices()
        self.with_context(validate_analytic=True).button_confirm()
        self.filtered(lambda o: o.state == 'purchase').write({'procurement_stage': 'shipment'})
        return True

    def action_ppf_mark_shipped(self):
        self._check_stage(('shipment',))
        self.procurement_stage = 'clearance'

    def action_ppf_mark_cleared(self):
        self._check_stage(('clearance',))
        self.procurement_stage = 'done'

    def _ppf_check_prices(self):
        for order in self:
            missing = order.order_line.filtered(
                lambda l: not l.display_type and l.product_qty and not l.price_unit)
            if missing:
                raise UserError(_(
                    "Unit price is missing on %(order)s for: %(products)s",
                    order=order.name,
                    products=', '.join(missing.mapped('product_id.display_name'))))

    # ------------------------------------------------------------------
    # Hooks into standard flow
    # ------------------------------------------------------------------
    def message_post(self, **kwargs):
        if self.env.context.get('ppf_vendor_request'):
            self.filtered(lambda o: o.procurement_stage in ('approval', 'resend', 'waiting_price')).write({
                'procurement_stage': 'waiting_price',
                'vendor_quote_submitted': False,
            })
        return super().message_post(**kwargs)

    def button_confirm(self):
        res = super().button_confirm()
        self.filtered(lambda o: o.state == 'purchase' and o.procurement_stage in BOARD_STAGES[:6]).write(
            {'procurement_stage': 'shipment'})
        return res

    def button_approve(self, force=False):
        res = super().button_approve(force=force)
        self.filtered(lambda o: o.state == 'purchase' and o.procurement_stage in BOARD_STAGES[:6]).write(
            {'procurement_stage': 'shipment'})
        return res

    def button_cancel(self):
        res = super().button_cancel()
        self.filtered(lambda o: o.state == 'cancel').write({'procurement_stage': 'cancel'})
        return res

    def button_draft(self):
        res = super().button_draft()
        self.write({'procurement_stage': 'draft', 'checked_by_id': False, 'request_approved_by_id': False,
                    'vendor_quote_submitted': False})
        return res

    def _ppf_vendor_submit(self, line_prices, vals):
        """Called (sudo) from the vendor portal."""
        self.ensure_one()
        for line, price, remark in line_prices:
            line.write({'price_unit': price, 'vendor_remark': remark})
        vals.update({
            'vendor_quote_submitted': True,
            'vendor_quote_date': fields.Datetime.now(),
            'procurement_stage': 'to_issue',
        })
        self.write(vals)
        body = _("Vendor submitted prices through the price-request link (total %(total)s).",
                 total='%s %s' % (self.currency_id.name, '{:,.2f}'.format(self.amount_total)))
        self.message_post(body=body, author_id=self.partner_id.id,
                          message_type='comment', subtype_xmlid='mail.mt_note')
        if self.user_id:
            self.activity_schedule(
                'mail.mail_activity_data_todo', user_id=self.user_id.id,
                summary=_('Vendor prices received – review and issue PO'))


class PurchaseOrderLine(models.Model):
    _inherit = 'purchase.order.line'

    vendor_remark = fields.Char(string='Vendor Remark', copy=False)
    ppf_sequence_no = fields.Integer(string='SRN', compute='_compute_ppf_sequence_no')

    @api.depends('order_id.order_line', 'sequence', 'display_type')
    def _compute_ppf_sequence_no(self):
        for order in self.mapped('order_id'):
            n = 0
            for line in order.order_line.sorted(lambda l: (l.sequence, l.id or 0)):
                if line.display_type:
                    line.ppf_sequence_no = 0
                else:
                    n += 1
                    line.ppf_sequence_no = n
        (self - self.filtered('order_id')).ppf_sequence_no = 0

    def _ppf_description(self):
        """Line description without the leading [CODE]."""
        self.ensure_one()
        name = self.label or self.name or ''
        code = self.product_id.default_code
        if code and name.startswith('[%s] ' % code):
            name = name[len(code) + 3:]
        return name


class ResCurrency(models.Model):
    _inherit = 'res.currency'

    def _ppf_rate_label(self, company, date):
        if not self:
            return False
        self.ensure_one()
        if not company or self == company.currency_id:
            return False
        rate = self._get_conversion_rate(self, company.currency_id, company,
                                         fields.Date.to_date(date) or fields.Date.context_today(self))
        return '1 %s = %s %s' % (self.name, '{:,.4f}'.format(rate), company.currency_id.name)
