{
    'name': 'Purchase Procurement Workflow',
    'version': '20.0.1.0.0',
    'category': 'Inventory/Purchase',
    'summary': 'Procurement Kanban dashboard, vendor price-request link, '
               'Order Request print and per-transaction currency',
    'description': """
Procurement workflow for Purchase
=================================
* Kanban dashboard (default view of the Purchase app) with stages:
  Drafted Orders, Pending Checking, Pending Approval, Waiting for Prices,
  Resend Vendor, Pending to Issue PO, Pending Shipment, Pending Clearance.
* Order Request document (quotation-style layout, prices left blank):
  SRN, Code, Description, Picture, UOM, Qty, Unit Price, Amount.
* E-mail to vendor with a secure link where the vendor fills in prices.
* Currency selectable on every transaction (default company currency, MVR),
  Exchange Rates menu under Purchase / Sales / Invoicing configuration.
""",
    'author': 'PSMS',
    'license': 'LGPL-3',
    'depends': ['purchase_stock', 'sale', 'portal'],
    'data': [
        'report/order_request_report.xml',
        'data/mail_template_data.xml',
        'views/purchase_order_views.xml',
        'views/vendor_portal_templates.xml',
        'views/currency_views.xml',
        'views/sale_order_views.xml',
    ],
    'post_init_hook': '_post_init_hook',
    'installable': True,
    'application': False,
}
