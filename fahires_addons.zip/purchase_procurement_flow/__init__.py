from . import models
from . import controllers


def _post_init_hook(env):
    """Put existing orders in the matching Kanban column."""
    orders = env['purchase.order'].search([])
    for order in orders:
        order.procurement_stage = order._guess_procurement_stage()
