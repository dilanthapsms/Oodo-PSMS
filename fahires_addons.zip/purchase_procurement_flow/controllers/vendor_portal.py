from odoo import http
from odoo.http import request
from odoo.tools import consteq
from odoo.tools.image import image_data_uri

from ..models.purchase_order import VENDOR_EDITABLE_STAGES


class VendorPriceRequest(http.Controller):

    def _get_order(self, order_id, access_token):
        order = request.env['purchase.order'].sudo().browse(order_id).exists()
        if not order or not access_token or not order.access_token \
                or not consteq(order.access_token, access_token):
            return None
        return order

    def _render(self, order, access_token, error=None, saved=False):
        lines = order.order_line.filtered(lambda l: l.display_type or l.product_qty)
        return request.render('purchase_procurement_flow.vendor_price_page', {
            'order': order,
            'lines': lines,
            'access_token': access_token,
            'editable': order.procurement_stage in VENDOR_EDITABLE_STAGES,
            'error': error,
            'saved': saved,
            'image_data_uri': image_data_uri,
            'company': order.company_id,
        })

    @http.route('/vendor/price-request/<int:order_id>', type='http', auth='public',
                methods=['GET'], website=False, sitemap=False)
    def price_request_form(self, order_id, access_token=None, **kw):
        order = self._get_order(order_id, access_token)
        if not order:
            return request.not_found()
        return self._render(order, access_token)

    @http.route('/vendor/price-request/<int:order_id>/submit', type='http', auth='public',
                methods=['POST'], website=False, sitemap=False)
    def price_request_submit(self, order_id, access_token=None, **post):
        order = self._get_order(order_id, access_token)
        if not order:
            return request.not_found()
        if order.procurement_stage not in VENDOR_EDITABLE_STAGES:
            return self._render(order, access_token)

        line_prices, missing = [], []
        for line in order.order_line.filtered(lambda l: not l.display_type and l.product_qty):
            raw = (post.get('price_%s' % line.id) or '').replace(',', '').strip()
            try:
                price = float(raw)
            except ValueError:
                price = None
            if price is None or price < 0:
                missing.append(line.product_id.display_name)
                continue
            remark = (post.get('remark_%s' % line.id) or '').strip()[:250]
            line_prices.append((line, price, remark))
        if missing:
            return self._render(order, access_token,
                                error='Please enter a valid unit price for: %s' % ', '.join(missing))

        vals = {
            'vendor_quote_ref': (post.get('vendor_quote_ref') or '').strip()[:100] or False,
            'vendor_lead_time': (post.get('vendor_lead_time') or '').strip()[:100] or False,
            'vendor_quote_validity': (post.get('vendor_quote_validity') or '').strip()[:100] or False,
            'vendor_quote_note': (post.get('vendor_quote_note') or '').strip()[:2000] or False,
        }
        order._ppf_vendor_submit(line_prices, vals)
        return self._render(order, access_token, saved=True)
