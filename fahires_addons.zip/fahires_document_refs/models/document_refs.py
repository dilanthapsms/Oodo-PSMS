from odoo import api, fields, models


def _join(names):
    return ", ".join(n for n in dict.fromkeys(names) if n) or False


class SaleOrder(models.Model):
    _inherit = "sale.order"

    client_order_ref = fields.Char(string="Customer Order Ref No.")
    customer_po_no = fields.Char("Customer PO No.", copy=False, tracking=True, index=True,
                                 help="The customer's purchase order number.")
    invoice_numbers = fields.Char("Invoice No.", compute="_compute_doc_numbers")
    dn_numbers = fields.Char("DN No.", compute="_compute_doc_numbers")

    @api.depends("invoice_ids.name", "fahires_delivery_ids.name", "fahires_delivery_ids.stage_code")
    def _compute_doc_numbers(self):
        for order in self:
            invoices = order.invoice_ids.filtered(lambda m: m.state != "cancel" and m.name and m.name != "/")
            order.invoice_numbers = _join(invoices.mapped("name"))
            order.dn_numbers = _join(order.fahires_delivery_ids.filtered(
                lambda d: d.stage_code != "cancelled").mapped("name"))

    def _prepare_invoice(self):
        vals = super()._prepare_invoice()
        vals["customer_po_no"] = self.customer_po_no
        return vals


class AccountMove(models.Model):
    _inherit = "account.move"

    customer_po_no = fields.Char("Customer PO No.", copy=False, tracking=True, index=True)
    qt_numbers = fields.Char("QT No.", compute="_compute_fahires_refs")
    customer_order_ref = fields.Char("Customer Order Ref No.", compute="_compute_fahires_refs")
    dn_numbers = fields.Char("DN No.", compute="_compute_fahires_refs")

    @api.depends("invoice_line_ids.sale_line_ids", "ref")
    def _compute_fahires_refs(self):
        for move in self:
            orders = move.invoice_line_ids.sale_line_ids.order_id.sudo()
            move.qt_numbers = _join(orders.mapped("name"))
            move.customer_order_ref = _join(orders.mapped("client_order_ref")) or (
                move.ref if move.ref and move.ref not in orders.mapped("name") else False)
            move.dn_numbers = _join(orders.fahires_delivery_ids.filtered(
                lambda d: d.stage_code != "cancelled").mapped("name"))


class Delivery(models.Model):
    _inherit = "fahires.delivery"

    customer_order_ref = fields.Char("Customer Order Ref No.", readonly=True)
    customer_po_no = fields.Char("Customer PO No.", readonly=True)
    invoice_numbers = fields.Char("Invoice No.", compute="_compute_invoice_numbers")

    def _compute_invoice_numbers(self):
        for rec in self:
            order = rec.sudo().sale_order_id
            invoices = order.invoice_ids.filtered(lambda m: m.state != "cancel" and m.name and m.name != "/")
            rec.invoice_numbers = _join(invoices.mapped("name"))

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("sale_order_id"):
                order = self.env["sale.order"].sudo().browse(vals["sale_order_id"])
                vals.setdefault("customer_order_ref", order.client_order_ref)
                vals.setdefault("customer_po_no", order.customer_po_no)
        return super().create(vals_list)


class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    product_code = fields.Char(related="product_id.default_code", string="Product Code")


class AccountMoveLine(models.Model):
    _inherit = "account.move.line"

    product_code = fields.Char(related="product_id.default_code", string="Product Code")
