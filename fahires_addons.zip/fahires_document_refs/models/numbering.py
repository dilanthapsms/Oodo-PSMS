from odoo import api, fields, models


def _preview_from_sequence(env, sequence, date=None):
    """Next number of an ir.sequence WITHOUT consuming it."""
    if not sequence:
        return False
    try:
        current = sequence._get_current_sequence(date)
        ctx = {"ir_sequence_date": date or fields.Date.context_today(sequence)}
        if current._name == "ir.sequence.date_range":
            ctx["ir_sequence_date_range"] = current.date_from
        return sequence.with_context(**ctx).get_next_char(current.number_next_actual)
    except Exception:  # never block the form for a preview
        return False


class SaleOrder(models.Model):
    _inherit = "sale.order"

    next_number_preview = fields.Char("Number on Save", compute="_compute_next_number_preview")

    @api.depends("company_id", "date_order")
    def _compute_next_number_preview(self):
        for order in self:
            if order._origin.id:
                order.next_number_preview = False
                continue
            seq = self.env["ir.sequence"].sudo().with_company(order.company_id or self.env.company).search(
                [("code", "=", "sale.order"), ("company_id", "in", [(order.company_id or self.env.company).id, False])],
                order="company_id", limit=1)
            order.next_number_preview = _preview_from_sequence(self.env, seq)


class Delivery(models.Model):
    _inherit = "fahires.delivery"

    next_number_preview = fields.Char("Number on Save", compute="_compute_next_number_preview")

    def _compute_next_number_preview(self):
        seq = self.env["ir.sequence"].sudo().search([("code", "=", "fahires.delivery")], limit=1)
        for rec in self:
            rec.next_number_preview = False if rec._origin.id else _preview_from_sequence(self.env, seq)


class StockPicking(models.Model):
    _inherit = "stock.picking"

    next_number_preview = fields.Char("Number on Save", compute="_compute_next_number_preview")

    @api.depends("picking_type_id")
    def _compute_next_number_preview(self):
        for rec in self:
            rec.next_number_preview = False if rec._origin.id else _preview_from_sequence(
                self.env, rec.picking_type_id.sudo().sequence_id)


class PurchaseOrder(models.Model):
    _inherit = "purchase.order"

    next_number_preview = fields.Char("Number on Save", compute="_compute_next_number_preview")

    @api.depends("company_id", "date_order")
    def _compute_next_number_preview(self):
        for order in self:
            if order._origin.id:
                order.next_number_preview = False
                continue
            company = order.company_id or self.env.company
            seq = self.env["ir.sequence"].sudo().search(
                [("code", "=", "purchase.order"), ("company_id", "in", [company.id, False])],
                order="company_id", limit=1)
            order.next_number_preview = _preview_from_sequence(self.env, seq)
