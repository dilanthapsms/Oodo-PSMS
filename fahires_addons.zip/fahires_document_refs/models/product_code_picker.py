from odoo import api, fields, models


class ProductProduct(models.Model):
    _inherit = "product.product"

    @api.depends_context(
        "fahires_code_only", "display_default_code", "seller_id", "company_id",
        "partner_id", "formatted_display_name", "lang",
    )
    def _compute_display_name(self):
        if self.env.context.get("fahires_code_only"):
            for product in self:
                product.display_name = product.default_code or product.name
            return
        return super()._compute_display_name()

    @api.model
    @api.readonly
    def web_name_search(self, name, specification, domain=None, operator="ilike", limit=100):
        # The dropdown always shows "[CODE] Name"; only the chosen value shows the code alone.
        return super(ProductProduct, self.with_context(fahires_code_only=False)).web_name_search(
            name, specification, domain=domain, operator=operator, limit=limit
        )


class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    product_image = fields.Image(related="product_id.image_128", string="Image")
    code_product_id = fields.Many2one(
        "product.product", string="Product Code",
        compute="_compute_code_product_id", inverse="_inverse_code_product_id",
        domain="[('sale_ok', '=', True)]",
        help="Type a product code or name to pick the product.",
    )

    def onchange(self, values, field_names, fields_spec):
        # The code-only display context of the "Product Code" column must not
        # leak into the line description computed during the onchange.
        if self.env.context.get("fahires_code_only"):
            self = self.with_context(fahires_code_only=False)
        return super(SaleOrderLine, self).onchange(values, field_names, fields_spec)

    @api.depends("product_id")
    def _compute_code_product_id(self):
        for line in self:
            line.code_product_id = line.product_id

    def _inverse_code_product_id(self):
        for line in self:
            if line.code_product_id and line.code_product_id != line.product_id:
                line.product_id = line.code_product_id

    @api.onchange("code_product_id")
    def _onchange_code_product_id(self):
        if self.code_product_id and self.code_product_id != self.product_id:
            self.product_id = self.code_product_id
