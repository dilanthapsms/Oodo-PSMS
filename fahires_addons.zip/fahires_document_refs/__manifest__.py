{
    "name": "Fahires Document References",
    "version": "20.0.1.0.0",
    "category": "Sales/Sales",
    "summary": "QT No., Customer Order Ref No., Customer PO No., Invoice No. and DN No. on every document and PDF",
    "author": "Fahires",
    "license": "LGPL-3",
    "depends": ["fahires_delivery", "account"],
    "data": [
        "views/document_refs_views.xml",
        "report/report_refs.xml",
    ],
    "installable": True,
}
